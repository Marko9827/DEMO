
document.getElementById("galerija").src = "pr_TPsve.html";
document.getElementById("Bsve").style = "border-bottom: 2px #1cb9ed solid;";
document.getElementById("B1").style = "border-bottom: 0px #1cb9ed solid;";
document.getElementById("B2").style = "border-bottom: 0px #1cb9ed solid;";
document.getElementById("B3").style = "border-bottom: 0px #1cb9ed solid;";
document.getElementById("B4").style = "border-bottom: 0px #1cb9ed solid;";
document.getElementById("B5").style = "border-bottom: 0px #1cb9ed solid;";
document.getElementById("B6").style = "border-bottom: 0px #1cb9ed solid;";
function Bsve() {
    document.getElementById("galerija").src = "pr_TPsve.html";
    document.getElementById("Bsve").style = "border-bottom: 2px #1cb9ed solid;";
    document.getElementById("B1").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B2").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B3").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B4").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B5").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B6").style = "border-bottom: 0px #1cb9ed solid;";

}
function B1() {
    document.getElementById("galerija").src = "pr_TP2.html";
    document.getElementById("Bsve").style = "border-bottom: 0px #1cb9ed solid;";
    alert("b1");
    document.getElementById("B1").style = "border-bottom: 2px #1cb9ed solid;";
    document.getElementById("B2").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B3").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B4").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B5").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B6").style = "border-bottom: 0px #1cb9ed solid;";

}


function B2() {

    document.getElementById("galerija").src = "pr_TP3.html";
    document.getElementById("Bsve").style = "border-bottom: 0px #1cb9ed solid;";

    document.getElementById("B1").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B2").style = "border-bottom: 2px #1cb9ed solid;";
    document.getElementById("B3").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B4").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B5").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B6").style = "border-bottom: 0px #1cb9ed solid;";
}


function B3() {

    document.getElementById("galerija").src = "pr_TP4.html";
    document.getElementById("Bsve").style = "border-bottom: 0px #1cb9ed solid;";

    document.getElementById("B1").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B2").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B3").style = "border-bottom: 3px #1cb9ed solid;";
    document.getElementById("B4").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B5").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B6").style = "border-bottom: 0px #1cb9ed solid;";
}

function B4() {    document.getElementById("galerija").src = "index.html";

    document.getElementById("Bsve").style = "border-bottom: 0px #1cb9ed solid;";

    document.getElementById("B1").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B2").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B3").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B4").style = "border-bottom: 2px #1cb9ed solid;";
    document.getElementById("B5").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B6").style = "border-bottom: 0px #1cb9ed solid;";
}

function B5() { document.getElementById("galerija").src = "pr_TP5.html";
    document.getElementById("Bsve").style = "border-bottom: 0px #1cb9ed solid;";

   
    document.getElementById("B1").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B2").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B3").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B4").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B5").style = "border-bottom: 2px #1cb9ed solid;";
    document.getElementById("B6").style = "border-bottom: 0px #1cb9ed solid;";
}


function B6() {    document.getElementById("galerija").src = "pr_TP6.html";
    document.getElementById("Bsve").style = "border-bottom: 0px #1cb9ed solid;";


    document.getElementById("B1").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B2").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B3").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B4").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B5").style = "border-bottom: 0px #1cb9ed solid;";
    document.getElementById("B6").style = "border-bottom: 2px #1cb9ed solid;";
}